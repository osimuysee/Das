let playerX = "";
let playerO = "";
let currentPlayer = "X";
let gameActive = false;
let boardState = Array(9).fill(null);
let scores = { X: 0, O: 0, draw: 0 };

const cells = document.querySelectorAll(".cell");
const statusText = document.getElementById("status");
const scoreX = document.getElementById("scoreX");
const scoreO = document.getElementById("scoreO");
const draws = document.getElementById("draws");
const restartButton = document.getElementById("restartBtn");

const winConditions = [
  [0, 1, 2], [3, 4, 5], [6, 7, 8], // rows
  [0, 3, 6], [1, 4, 7], [2, 5, 8], // columns
  [0, 4, 8], [2, 4, 6]             // diagonals
];

cells.forEach(cell => {
  cell.addEventListener("click", () => {
    const index = cell.getAttribute("data-index");
    if (!gameActive || boardState[index]) return;

    boardState[index] = currentPlayer;
    cell.textContent = currentPlayer;

    if (checkWinner()) {
      gameActive = false;
      scores[currentPlayer]++;
      updateScores();
      statusText.textContent = `${getPlayerName(currentPlayer)} wins!`;
      restartButton.style.display = "inline-block";
    } else if (!boardState.includes(null)) {
      gameActive = false;
      scores.draw++;
      updateScores();
      statusText.textContent = "It's a draw!";
      restartButton.style.display = "inline-block";
    } else {
      currentPlayer = currentPlayer === "X" ? "O" : "X";
      statusText.textContent = `${getPlayerName(currentPlayer)}'s turn`;
    }
  });
});

function getPlayerName(symbol) {
  return symbol === "X" ? playerX : playerO;
}

function checkWinner() {
  return winConditions.some(combo => {
    const [a, b, c] = combo;
    return (
      boardState[a] &&
      boardState[a] === boardState[b] &&
      boardState[a] === boardState[c]
    );
  });
}

function updateScores() {
  scoreX.textContent = `${playerX || "Player X"}: ${scores.X}`;
  scoreO.textContent = `${playerO || "Player O"}: ${scores.O}`;
  draws.textContent = `Draws: ${scores.draw}`;
}

function startGame() {
  playerX = document.getElementById("playerX").value.trim() || "Player X";
  playerO = document.getElementById("playerO").value.trim() || "Player O";

  boardState = Array(9).fill(null);
  currentPlayer = "X";
  gameActive = true;
  restartButton.style.display = "none";

  cells.forEach(cell => {
    cell.textContent = "";
    cell.style.pointerEvents = "auto";
  });

  document.querySelector(".player-inputs").style.display = "none";
  statusText.textContent = `${playerX}'s turn`;
}

function resetGame() {
  boardState = Array(9).fill(null);
  currentPlayer = "X";
  gameActive = true;
  restartButton.style.display = "none";

  cells.forEach(cell => {
    cell.textContent = "";
    cell.style.pointerEvents = "auto";
  });

  statusText.textContent = `${playerX}'s turn`;
}
